<?php /*Copyright ? 2008-2014. Team Beyond Borders Pty Ltd. All rights reserved.*/
	/***********************************************************************************************************
	*  *  *  *  *  *  *  *  *  *  *   I D E AV A T E   S O L U T I O N S   *  *  *  *  *  *  *  *   *
	************************************************************************************************************
	* Filename				: add_work_place_member.php
	* Description 		  	: A class file used to add the work place members
	* External Files called	: models/dal/idenityDBManage.php, models/dal/time_manager.php, models/user/usser.php, models/mailer/mailer.php, CI_Controllers/admin/add_work_place_member.php
								models/dal/mailer_manager.php,models/identity/teeme_managers.php,views/admin/add_work_place_member, views/login.php 
	* Global Variables	  	: 
	* 
	* Modification Log
	* 	Date                	 Author                       		Description
	* ---------------------------------------------------------------------------------------------------------
	* 10-10-2008				Nagalingam						Created the file.			
	* 24-11-2208				Nagalingam						Modified the file for time_manager functionalities
	**********************************************************************************************************/
/*
* this class is used to add the work place members
*/
function index()
	{		
				
		if(!isset($_SESSION['adminUserName']) || $_SESSION['adminUserName'] =='')
		{
			redirect('instance/login', 'location');
		}
		else
		{						
			$this->load->view('instance/home');		
		}
	}
function new_changes()
{
	echo 'update installed successfully';
}
?>